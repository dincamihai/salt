=================
salt.grains.metadata
=================

.. automodule:: salt.grains.metadata
    :members:
