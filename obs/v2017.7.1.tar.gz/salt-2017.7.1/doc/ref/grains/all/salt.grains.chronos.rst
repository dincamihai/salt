===================
salt.grains.chronos
===================

.. automodule:: salt.grains.chronos
    :members:
