===================
salt.auth.stormpath
===================

.. automodule:: salt.auth.stormpath
    :members: