salt.cache.localfs module
=========================

.. automodule:: salt.cache.localfs
    :members:
