===========================
salt.cloud.clouds.openstack
===========================

.. automodule:: salt.cloud.clouds.openstack
    :members: