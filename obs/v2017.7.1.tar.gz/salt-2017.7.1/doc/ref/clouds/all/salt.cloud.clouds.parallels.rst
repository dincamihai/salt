===========================
salt.cloud.clouds.parallels
===========================

.. automodule:: salt.cloud.clouds.parallels
    :members: