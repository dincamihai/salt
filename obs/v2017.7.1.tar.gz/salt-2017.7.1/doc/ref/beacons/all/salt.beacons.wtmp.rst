=================
salt.beacons.wtmp
=================

.. automodule:: salt.beacons.wtmp
    :members: