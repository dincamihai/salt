salt.beacons.status module
==========================

.. automodule:: salt.beacons.status
    :members:
    :undoc-members:
