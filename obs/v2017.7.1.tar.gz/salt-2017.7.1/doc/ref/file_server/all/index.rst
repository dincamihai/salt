.. _all-salt.fileserver:

==================
fileserver modules
==================

.. currentmodule:: salt.fileserver

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    azurefs
    gitfs
    hgfs
    minionfs
    roots
    s3fs
    svnfs
