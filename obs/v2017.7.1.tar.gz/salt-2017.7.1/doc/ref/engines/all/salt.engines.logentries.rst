=======================
salt.engines.logentries
=======================

.. automodule:: salt.engines.logentries
    :members:
