================
salt.modules.lxc
================

.. automodule:: salt.modules.lxc
    :members:
    :exclude-members: cp, set_pass, remove
