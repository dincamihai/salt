================
salt.modules.nix
================

.. automodule:: salt.modules.nix
    :members:
