===================
salt.modules.layman
===================

.. automodule:: salt.modules.layman
    :members: