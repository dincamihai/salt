======================
salt.modules.firewalld
======================

.. automodule:: salt.modules.firewalld
    :members:
