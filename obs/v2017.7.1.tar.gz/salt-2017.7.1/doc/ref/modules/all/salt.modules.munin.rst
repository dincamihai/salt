==================
salt.modules.munin
==================

.. automodule:: salt.modules.munin
    :members: