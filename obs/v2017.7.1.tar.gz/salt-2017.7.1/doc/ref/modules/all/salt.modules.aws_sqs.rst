====================
salt.modules.aws_sqs
====================

.. automodule:: salt.modules.aws_sqs
    :members: