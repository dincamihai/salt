salt.modules.msteams module
===========================

.. automodule:: salt.modules.msteams
    :members:
    :undoc-members:
