salt.modules.boto_efs module
============================

.. automodule:: salt.modules.boto_efs
    :members:
    :undoc-members:
