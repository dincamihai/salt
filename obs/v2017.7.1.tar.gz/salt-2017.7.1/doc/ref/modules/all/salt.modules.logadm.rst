===================
salt.modules.logadm
===================

.. automodule:: salt.modules.logadm
    :members: