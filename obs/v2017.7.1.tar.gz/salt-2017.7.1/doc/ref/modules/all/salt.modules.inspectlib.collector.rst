salt.modules.inspectlib.collector module
========================================

.. automodule:: salt.modules.inspectlib.collector
    :members:
