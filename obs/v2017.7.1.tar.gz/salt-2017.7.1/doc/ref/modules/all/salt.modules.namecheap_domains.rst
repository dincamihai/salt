salt.modules.namecheap_domains module
=====================================

.. automodule:: salt.modules.namecheap_domains
    :members:
    :undoc-members:
