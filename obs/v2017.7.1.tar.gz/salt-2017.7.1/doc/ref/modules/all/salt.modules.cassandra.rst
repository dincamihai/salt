======================
salt.modules.cassandra
======================

.. automodule:: salt.modules.cassandra
    :members: