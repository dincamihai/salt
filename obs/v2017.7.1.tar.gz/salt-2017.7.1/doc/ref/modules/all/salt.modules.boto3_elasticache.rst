salt.modules.boto3_elasticache module
=====================================

.. automodule:: salt.modules.boto3_elasticache
    :members:
    :undoc-members:
