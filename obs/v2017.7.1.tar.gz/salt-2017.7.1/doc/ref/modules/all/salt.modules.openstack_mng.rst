salt.modules.openstack_mng module
=================================

.. automodule:: salt.modules.openstack_mng
    :members:
    :undoc-members:
